package persistencia25Nov;

import java.util.Arrays;
import java.util.Scanner;

public class Zoologico implements java.io.Serializable{
	private String cod;
	private String nombre;
	private int nroAnimales;
	private Animal[]a = new Animal[50];
	
	public Zoologico(String cod, String nombre) {

		this.cod = cod;
		this.nombre = nombre;
		this.nroAnimales = 0;
	}
	public Zoologico() {
		this.nroAnimales = 0;

		
	}
	public void leer()
	{
		Scanner lee = new Scanner(System.in);

    
        System.out.print("Ingrese el cod - nombre");
        this.cod= lee.nextLine();
        this.nombre= lee.nextLine();

	
	}
	
	
	public String getCod() {
		return cod;
	}
	public void setCod(String cod) {
		this.cod = cod;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getNroAnimales() {
		return nroAnimales;
	}
	public void setNroAnimales(int nroAnimales) {
		this.nroAnimales = nroAnimales;
	}
	public Animal[] getA() {
		return a;
	}
	public Animal getA(int i) {
		return a[i];
	}
	public void setA(Animal[] a) {
		this.a = a;
	}

	public String toString() {
		return "Zoologico [cod=" + cod + ", nombre=" + nombre + ", nroAnimales=" + nroAnimales + "]";
	}
	
	public void adiAnimal(Animal a)
	{
		this.a[this.nroAnimales]=a;
		this.nroAnimales++;
	}
	public void mostrar()
	{
		System.out.println(toString());
		for (int i = 0; i < this.nroAnimales; i++) {
			a[i].mostrar();
			
		}
	}
	
	
	
	

}
