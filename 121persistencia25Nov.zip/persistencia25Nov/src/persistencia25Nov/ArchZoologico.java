package persistencia25Nov;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class ArchZoologico {
	private String nomArch;
	private Zoologico z;
	
	public ArchZoologico(String nom){
		this.nomArch = nom;
	}
	public void crear() throws ClassNotFoundException, IOException{
		ObjectOutputStream aZoologico = new ObjectOutputStream(new FileOutputStream(nomArch));
		aZoologico.close();
	}
	public void adicionar(Zoologico z) throws ClassNotFoundException, IOException{
		String op;
		Scanner lee = new Scanner(System.in);
		ObjectOutputStream aZoologico = null;
		try {
			if(new File(nomArch).exists()){
				aZoologico = new AddObjectOutputStream(new FileOutputStream(nomArch,true));
			}else{					
				aZoologico = new ObjectOutputStream(new FileOutputStream(nomArch,true));
			}
			
			do{
//				rLib = new RegLibro();
//				rLib.leer();
				aZoologico.writeObject(z);
				System.out.println("Desea cont s/n");
				op = lee.next();
			}while(op.equals("s"));
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fin adicion");
		}finally{
			aZoologico.close();
		}
	}
	
//	public boolean eliminar(String nombre) throws ClassNotFoundException,IOException{
//		boolean sw = false;
//		ObjectInputStream aZoologico = null;
//		ObjectOutputStream arAux = null;
//		
//		try {
//			aZoologico = new ObjectInputStream(new FileInputStream(nomArch));
//			arAux = new ObjectOutputStream(new FileOutputStream("copia.dat", true));
//			while(true){
//				z = new Zoologico();
//				z = (Zoologico)aZoologico.readObject();
//				if(rLib.getCod().equals(nombre))
//					sw = true;
//				else
//					arAux.writeObject(rLib);
//			}
//		} catch (Exception e) {
//			System.out.print("\n FIN ELIMINA");
//		}finally{
//			arLib.close();
//			arAux.close();
//			File f1 = new File(nomArch);
//			File f2 = new File("copia.dat");
//			f1.delete();
//			f2.renameTo(f1);
//		}
//		return sw;
//	}
//	public boolean modificar(String cod)throws ClassNotFoundException,IOException{
//		Scanner lee =new Scanner(System.in);
//		String resp;
//		boolean sw=false;
//		ObjectInputStream arLib = null;
//		ObjectOutputStream arAux = null;
//		try{
//			arLib = new ObjectInputStream(new FileInputStream(nomArch));
//			arAux = new ObjectOutputStream(new FileOutputStream("copia.dat", true));
//			while(true){
//				rLib =new RegLibro();
//				rLib =(RegLibro)arLib.readObject();
//				if(rLib.getCod().equals(cod)){
//					rLib.mostrar();
//					System.out.print("Desea modificar s/n");
//					 resp=lee.next();
//					if(resp.equals("s")){
//						System.out.print("introdusca titulo y precio");
//						 String titulo = lee.next();
//						 double precio = lee.nextDouble();
//						 rLib.setTitulo(titulo);
//						 rLib.setPrecio(precio);
//						 sw=true;
//					}
//				}
//				arAux.writeObject(arLib);
//			}
//		}
//		catch (Exception e) {
//			System.out.print("\n FIN Modifica");
//		}finally{
//			arLib.close();
//			arAux.close();
//			File f1 = new File(nomArch);
//			File f2 = new File("copia.dat");
//			f1.delete();
//			f2.renameTo(f1);
//		}
//		return sw;
//	}
	
	public void listar()throws ClassNotFoundException, IOException{
		ObjectInputStream aZoologico = null;
		try {
			aZoologico = new ObjectInputStream(new FileInputStream(nomArch));
			while(true){
				z= new Zoologico();
				z = (Zoologico)aZoologico.readObject();
				z.mostrar();
			}
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e.getMessage());
			System.out.println("Fin listado!!!!");
		}finally{
			aZoologico.close();
		}
	}
	public void listarCantidadTotalZoologico() throws ClassNotFoundException, IOException{
		
		ObjectInputStream aZoologico = null;
		try {
			aZoologico = new ObjectInputStream(new FileInputStream(nomArch));
			while(true){
				int nro=0;
				z= new Zoologico();
				z = (Zoologico)aZoologico.readObject();
			
				for (int i = 0; i < z.getNroAnimales(); i++) {
					
					 //nro=nro +z.getA(i).getCantidad();
					nro=nro +z.getA()[i].getCantidad();
					
					
				}
				System.out.println("total animales: "+nro);
				//z.mostrar();
			}
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e.getMessage());
			System.out.println("Fin listado!!!!");
		}finally{
			aZoologico.close();
		}
		
	}
	public void ListarZoologicoAnimal(String nomX)throws ClassNotFoundException, IOException {
		ObjectInputStream aZoologico = null;
		try {
			aZoologico = new ObjectInputStream(new FileInputStream(nomArch));
			while(true){
				boolean sw=false;
				z= new Zoologico();
				z = (Zoologico)aZoologico.readObject();
				//System.out.println("hola");
			
				for (int i = 0; i < z.getNroAnimales(); i++) {
					
					if(z.getA(i).getNombre().equals(nomX))
						sw = true;
				}
				if(sw)
					System.out.println("el nom de zoologico que tiene " +nomX +" es "+z.getNombre());
			}
		} catch (Exception e) {
			// TODO: handle exception
			//System.out.println(e.getMessage());
			System.out.println("error !!!!");
		}finally{
			aZoologico.close();
		}
		
	}
	
//	public void listarLibrosPrecioMayor(double preciox)throws ClassNotFoundException, IOException{
//		System.out.println("\nLista de libros mayores iguales a: " + preciox);
//		ObjectInputStream arLib = null;
//		try {
//			arLib = new ObjectInputStream(new FileInputStream(nomArch));
//			while(true){
//				rLib = new RegLibro();
//				rLib = (RegLibro)arLib.readObject();
//				if(rLib.getPrecio() >= preciox)
//					rLib.mostrar();
//			}
//		} catch (Exception e) {
//			// TODO: handle exception
//			//System.out.println(e.getMessage());
//			System.out.println("Fin listado!!!!");
//		}finally{
//			arLib.close();
//		}
//	}
	
//	public String buscarCodPorTitulo(String titulox) throws IOException, ClassNotFoundException {
//		ObjectInputStream arLib = null;
//		String codLib="";
//		try {
//			arLib = new ObjectInputStream(new FileInputStream(nomArch));
//			while(true){
//				rLib = new RegLibro();
//				rLib = (RegLibro)arLib.readObject();
//				if(rLib.getTitulo().equals(titulox))
//					codLib = rLib.getCod();
//				//rLib.mostrar();
//			}
//		} catch (Exception e) {
//			// TODO: handle exception
//			//System.out.println(e.getMessage());
//			//System.out.println("Fin buscar!!!!");
//		}finally{
//			arLib.close();
//		}
//		return codLib;
//	}

}
