package persistencia25Nov;

import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		Zoologico z1 = new Zoologico ("z1","Zoologico Mallasa ");
		Zoologico z2 = new Zoologico ("z3","Zoologico Central Park");
		//z1.mostrar();
		Animal a1 =new Animal("carnivoro", "leon", 2);
		Animal a2 =new Animal("ovnivoro", "tejon", 4);
		Animal a3 =new Animal("hervivoro", "oveja", 4);
		
		Animal a4 =new Animal("carnivoro", "oso", 3);
		Animal a5 =new Animal("ovnivoro", "javali", 4);
		Animal a6 =new Animal("hervivoro", "llama", 1);
		Animal a7 =new Animal("hervivoro", "vaca", 4);
		
		z1.adiAnimal(a1);
		z1.adiAnimal(a2);
		z1.adiAnimal(a3);
		
		z2.adiAnimal(a4);
		z2.adiAnimal(a5);
		z2.adiAnimal(a6);
		z2.adiAnimal(a7);
		
		
		//z1.mostrar();
		
		ArchZoologico az = new ArchZoologico("zoologico.dat");
		//az.crear();
		//az.adicionar(z1);
		///az.adicionar(z2);
		az.listar();
		
		System.out.println("\nCantidad Total de animale por zoologico");
		az.listarCantidadTotalZoologico();
		
		/// a) mostra el nombre del zoologico que tiene al animal de nombre oso
		az.ListarZoologicoAnimal("oso");
		System.out.println("SANDOVAL CALDERON KEVIN OSCAR 9904973");
		
		/// b) mostra el nombre del zoologico que tiene mas animales carnivoros TAREA
		//az.listarZoologicoMayorTipo("carnivoro");
		
		//lsitar el zoologico  con el nro de animales de tipo x
		//az.listarNroAnimales("carnivoro");
		
		
		
//		Scanner lee = new Scanner(System.in);
//		ArchLibro a = new ArchLibro("libro2025.dat");
//		String cod;
//		int op;
//		do {
//			System.out.println("\n\n ****** Menu de archivo Libro ******");
//			System.out.println("1. Crear"
//					+ "\n2. Adicionar"
//					+ "\n3. Eliminar"
//					+ "\n4. Modificar"
//					+ "\n5. Listar"
//					+ "\n6. Listar Libros con precio mayor a x"
//					+ "\n7. Salir");
//			op = lee.nextInt();
//			switch(op) {
//				case 1: a.crear();
//						break;
//				case 2: a.adicionar();
//						break;
//				case 3: System.out.println("Intr. codigo de libro");
//						cod = lee.next();
//						a.eliminar(cod);
//						break;
//				case 4: System.out.println("Intr. codigo de libro");
//						cod = lee.next();
//						a.modificar(cod);
//						break;
//				case 5: a.listar();
//						break;
//				case 6: a.listarLibrosPrecioMayor(100);
//						break;
//				case 7: System.out.println("Fin Programa!!!");
//						break;
//				default:System.out.println("no existe la opcion");
//			}
//		}while(op != 7);
		
		

	}

}
