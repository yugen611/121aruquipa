package persistencia25Nov;

import java.util.Scanner;

public class Animal implements java.io.Serializable{
	private String especie,nombre;
	private int cantidad;
	
	
	
	public Animal(String especie, String nombre, int catidad) {

		this.especie = especie;
		this.nombre = nombre;
		this.cantidad = catidad;
	}
	public Animal() {

	}
	
	
	public void leer()
	{
		Scanner lee = new Scanner(System.in);

    
        System.out.print("Ingrese su: especie - nombre - cantidad");
        this.especie= lee.nextLine();
        this.nombre= lee.nextLine();
        this.cantidad = lee.nextInt();
	
	}
	public void mostrar()
	{
		System.out.println("----------");
		System.out.println(this.especie);
		System.out.println(this.nombre);
		System.out.println(this.cantidad);
	}

	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	
	
	

}
